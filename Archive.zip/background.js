let whitelist = ['https://www.example.com'];

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && !whitelist.includes(tab.url)) {
    chrome.scripting.executeScript({
      target: {tabId: tab.id},
      function: () => {
        if (document.body.innerHTML.includes('game')) {
          chrome.runtime.sendMessage({closeTab: true});
        }
      }
    });
  }
});

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.closeTab) {
    chrome.tabs.remove(sender.tab.id);
  }
});